import { Component, OnInit, Input } from '@angular/core';
import { AppComponent } from '../app.component';

@Component({
  selector: 'app-score',
  template: `
    <p>
      score works! {{totalPoints}}
    </p>
  `,
  styles: []
})
export class ScoreComponent implements OnInit {

  @Input() totalPoints :number;
  constructor(private app: AppComponent) { }

  ngOnInit(): void {
    this.app.points = 50;
  }

}
