import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'my-app9';
  points = {'games': { 'pac_man':500} };
  available:boolean = true;
  count = [1,2,3];
}
